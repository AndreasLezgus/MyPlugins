---
name: quality-gates
description: Plan marketing campaigns with objectives, audience segmentation, channel strategy, content calendars, and success metrics. Use when launching a campaign, planning a product launch, building a content calendar, allocating budget across channels, or defining campaign KPIs.
---

# Workflow-Checkliste: Content-Pipeline

## Pre-Flight Check

- [ ] DEVONthink-Ordner 10.10-Social-Media enthält Dokumente
- [ ] Ulysses ist geöffnet und erreichbar (MCP-Verbindung aktiv)
- [ ] DEVONthink ist geöffnet und erreichbar (MCP-Verbindung aktiv)
- [ ] User hat Dokumentliste bestätigt

## Pro Dokument

### Blog-Artikel
- [ ] `/references/stimmprofil-andreas-md` Skill geladen (Schicht 1)
- [ ] `/workflows/blog-article.md` geladen (Schicht 2)
- [ ] Quelldokument gelesen (Schicht 3)
- [ ] Artikel generiert nach Template-Struktur
- [ ] Stimm-Check: Klingt wie Andreas?
- [ ] Anrede: durchgängig „Sie"
- [ ] Länge: 1500-2500 Wörter
- [ ] TL;DR vorhanden
- [ ] Handlungsempfehlungen konkret
- [ ] Quellen korrekt zitiert
- [ ] Markdown sauber (keine HTML-Tags)
- [ ] In Ulysses gespeichert: Blog/1-Ideen (`UaxFYZgfWzstxBwjRWXpUw`)
- [ ] Keywords: „Blog", „Pipeline", Thema-Tag

### LinkedIn-Beitrag
- [ ] `/references/stimmprofil-andreas.md` Skill geladen (Schicht 1)
- [ ] `/workflows/linkedin-article.md` geladen (Schicht 2)
- [ ] Blog-Artikel als Input verwendet (Schicht 3)
- [ ] NICHT nur zusammengefasst – provokanteste These extrahiert
- [ ] Hook-Zeile stark genug
- [ ] Länge: 150-300 Wörter
- [ ] Eine Kernbotschaft
- [ ] Diskussionsfrage vorhanden
- [ ] Blog-Link Platzhalter [BLOG-LINK] vorhanden
- [ ] 3-5 Hashtags am Ende
- [ ] In Ulysses gespeichert: LinkedIn/1-Ideen (`QIC4zWg_pU1WD9y3FKvS1Q`)
- [ ] Keywords: „LinkedIn", „Pipeline", Thema-Tag

### Substack-Artikel
- [ ] `/references/stimmprofil-andreas.md` Skill geladen (Schicht 1)
- [ ] `/workflows/substack-article.md` geladen (Schicht 2)
- [ ] Original-Quelldokument als Input (NICHT Blog-Artikel!)
- [ ] Anrede: durchgängig „Du"
- [ ] Persönlicher Einstieg (nicht akademisch)
- [ ] Länge: 1500-2500 Wörter
- [ ] TL;DR vorhanden
- [ ] Differenziert sich vom Blog-Artikel
- [ ] CTA: Teilen + Antworten einladen
- [ ] In Ulysses gespeichert: Substack/1-Ideen (`vakDORAkFmOO99q_YZAvoQ`)
- [ ] Keywords: „Substack", „Pipeline", Thema-Tag

## Post-Processing (nach ALLEN Dokumenten)

- [ ] ALLE Quelldokumente: Tag „Ulysses" gesetzt
- [ ] ALLE Quelldokumente: Verschoben nach 50.01-Gartner (`18B2F3AE-9D1E-448F-ABA2-236549FD71BA`)
- [ ] Abschlussbericht dem User gezeigt

## Häufige Fehler

| Fehler                            | Lösung                                                                      |
| --------------------------------- | --------------------------------------------------------------------------- |
| Substack klingt wie Blog-Kopie    | Eigenständig aus Quelldokument ableiten, „Du"-Anrede, persönlicher Einstieg |
| LinkedIn zu lang                  | Max. 300 Wörter. Eine These. Kein Mini-Artikel.                             |
| Stimme klingt generisch           | `/referentces/stimmprofil-andreas.md` erneut laden. Stimm-Kalibrierung prüfen.            |
| Quelldokument nur zusammengefasst | Eigene „Zweite Meinung" fehlt. Praxis-Perspektive ergänzen.                 |
| Dokumente zu früh verschoben      | Erst ALLE Artikel fertig, dann taggen und verschieben.                      |
| Blog-Artikel als Substack-Input   | Substack basiert auf dem Quelldokument, nicht auf dem Blog.                 |
